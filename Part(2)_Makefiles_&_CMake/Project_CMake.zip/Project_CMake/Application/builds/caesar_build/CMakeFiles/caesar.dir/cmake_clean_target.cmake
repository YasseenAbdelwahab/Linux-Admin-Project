file(REMOVE_RECURSE
  "/home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Application/out/libs/libcaesar.a"
)

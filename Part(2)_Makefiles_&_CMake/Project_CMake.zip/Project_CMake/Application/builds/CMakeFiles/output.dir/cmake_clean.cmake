file(REMOVE_RECURSE
  "/home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Application/output"
  "/home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Application/output.pdb"
  "CMakeFiles/output.dir/app.c.o"
  "CMakeFiles/output.dir/app.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/output.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

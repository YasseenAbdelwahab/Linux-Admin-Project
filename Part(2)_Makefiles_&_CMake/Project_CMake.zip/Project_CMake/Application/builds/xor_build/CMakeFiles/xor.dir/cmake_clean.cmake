file(REMOVE_RECURSE
  "/home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Application/out/libs/libxor.pdb"
  "/home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Application/out/libs/libxor.so"
  "CMakeFiles/xor.dir/src/xor_decrypt.c.o"
  "CMakeFiles/xor.dir/src/xor_decrypt.c.o.d"
  "CMakeFiles/xor.dir/src/xor_encrypt.c.o"
  "CMakeFiles/xor.dir/src/xor_encrypt.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/xor.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

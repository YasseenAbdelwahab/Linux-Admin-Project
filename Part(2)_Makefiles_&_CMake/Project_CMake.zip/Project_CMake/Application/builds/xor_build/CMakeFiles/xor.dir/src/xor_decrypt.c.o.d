xor_build/CMakeFiles/xor.dir/src/xor_decrypt.c.o: \
 /home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Modules/xor_cipher/src/xor_decrypt.c \
 /usr/include/stdc-predef.h \
 /home/yasseen/Downloads/Edges/Embedded_Linux_Diploma/Project1/Part(2)_Makefiles_&_CMake/Project_CMake/Modules/xor_cipher/./inc/xor_cipher.h
